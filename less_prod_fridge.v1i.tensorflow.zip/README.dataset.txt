# less_prod_fridge > 2024-11-03 12:51pm
https://universe.roboflow.com/fridge-j8zv6/less_prod_fridge

Provided by a Roboflow user
License: CC BY 4.0

